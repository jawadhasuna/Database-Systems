/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package db1;

import java.sql.Connection;
import java.sql.SQLException;

public class jawadloginandregistration {

    public static void main(String[] args) {

        // Connect to DB first
        try (Connection con = DBConnection.getConnection()) {
            System.out.println("Database connected successfully!");

            // Launch login form on EventQueue
            java.awt.EventQueue.invokeLater(() -> {
                new jayloginform().setVisible(true);
            });

        } catch (SQLException e) {
            System.out.println("Failed to connect to database: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

    
